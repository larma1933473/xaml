﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2_XAML.Model
{
    class Usager : INotifyPropertyChanged
    {
        
        private string nom;

        public Usager(string nom)
        {
            Pseudo = nom;
            
        }

        
        public string Pseudo
        {
            get { return nom; }
            set
            {
                nom = value;
                OnPropertyChanged("Pseudo");
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
