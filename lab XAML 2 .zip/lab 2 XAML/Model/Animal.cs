﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2_XAML.Model
{
    class Animal : INotifyPropertyChanged
    {
        protected int age;
        protected string nom;
        protected string typeAnimal;

        public Animal(string nom,string typeAnimal,int age)
        {
            Nom = nom;
            TypeAnimal = typeAnimal;
            Age = age;
        }

        public int Age
        {
            get { return age; }
            set
            {
                age = value;
                OnPropertyChanged("Age");
            }
        }

        public string Nom
        {
            get { return nom; }
            set
            {
                nom = value;
                OnPropertyChanged("Nom");
            }
        }
        public string TypeAnimal
        {
            get { return typeAnimal; }
            set
            {
                typeAnimal = value;
                OnPropertyChanged("TypeAnimal");
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
