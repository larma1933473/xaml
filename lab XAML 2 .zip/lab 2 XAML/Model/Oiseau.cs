﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2_XAML.Model
{
    class Oiseau : Animal
    {
        public Oiseau(string nom, int age) : base(nom,"Oiseau", age)
        {

        }
    }
}
