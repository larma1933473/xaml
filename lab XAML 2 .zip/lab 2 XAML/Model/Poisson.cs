﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2_XAML.Model
{
    class Poisson : Animal
    {
        public Poisson(string nom, int age) : base(nom,"Poisson", age)
        {

        }
    }
}
