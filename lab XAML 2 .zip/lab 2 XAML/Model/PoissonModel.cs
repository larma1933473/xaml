﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2_XAML.Model
{
    class PoissonModel : INotifyPropertyChanged
    {
        private string typeAnimal;
        private string nom;
        private int age;

        public PoissonModel(string typeAnimal, string nom, int age)
        {
            TypeAnimal = typeAnimal;
            Nom = nom;
            Age = age;
        }
        public string TypeAnimal
        {
            get { return typeAnimal; }
            set
            {
                typeAnimal = value;
                OnPropertyChanged("TypeAnimal");
            }
        }
        public string Nom
        {
            get { return nom; }
            set
            {
                nom = value;
                OnPropertyChanged("Nom");
            }
        }
        public int Age
        {
            get { return age; }
            set
            {
                age = value;
                OnPropertyChanged("Age");
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
