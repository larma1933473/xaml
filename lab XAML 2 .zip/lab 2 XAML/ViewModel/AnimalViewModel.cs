﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using lab_2_XAML.Model;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace lab_2_XAML.ViewModel
{
    class AnimalViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private ObservableCollection<Animal> listAnimal;
        private BaseViewModel fenetreActive;
        private MenuViewModel menu;

        public AnimalViewModel()
        {
            fenetreActive = this;
            menu = new MenuViewModel();

           listAnimal=new ObservableCollection<Animal>();
            listAnimal.Add(new Poisson("Nemo",16));
            listAnimal.Add(new Chat("Tom", 79));
            listAnimal.Add(new Oiseau("Zazou", 79));
        }
        public ObservableCollection<Animal> ListAnimal
        {
            get { return listAnimal; }
        }

        public BaseViewModel FenetreActive
        {
            get { return fenetreActive; }
            set
            {
                fenetreActive = value;
                OnPropertyChanged("FenetreActive");
            }
        }
        public MenuViewModel LeMenu
        {
            get { return menu; }
            set
            {
                menu = value;
                OnPropertyChanged("LeMenu");
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
