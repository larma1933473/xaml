﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using lab_2_XAML.Commande;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace lab_2_XAML.ViewModel
{
    class MenuViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private Sauvegarder sauvegarder;
        private Quitter quitter;
        public MenuViewModel()
        {
            sauvegarder = new Sauvegarder(this);
            quitter = new Quitter(this);
        }
        public void ASauvegarder()
        {
            
            MessageBox.Show("Vous avez bien sauvegardé! ","Sauvegarde");
        }
        public void AQuitter()
        {
            MessageBox.Show("Il faut clicker sur le X en haut a droite pour quitter! ","Quitter");
        }

        public bool PeutSauvegarder()
        {
            
            return true;
        }
        public bool PeutQuitter()
        {
            
            return true;
        }
        public Sauvegarder SauvegarderDuMenu
        {
            get { return sauvegarder; }
            set
            {
                sauvegarder = value;
                
            }
        }
        public Quitter QuitterLeMenu
        {
            get { return quitter; }
            set
            {
                quitter = value;
                
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
