﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using lab_2_XAML.Model;
using lab_2_XAML.Commande;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2_XAML.ViewModel
{
    class MainViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private ConfirmerBonUsager connecter;
        private Usager usager;
        private BaseViewModel fenetreActive;
        private MenuViewModel menu;
        public MainViewModel()
        {
            fenetreActive = this;
            connecter = new ConfirmerBonUsager(this);
            usager = new Usager("");
            menu = new MenuViewModel();
        }
        public ConfirmerBonUsager Connecter
        {
            get { return connecter; }
            set
            {
                connecter = value;

            }
        }
     
        public Usager LeUsager
        {
            get { return usager; }
            set
            {
                usager = value;
                OnPropertyChanged("LeUsager");
            }
        }
        public void SeConnecter()
        {
            string bonUsager= "Matis";

            if(LeUsager.Pseudo==bonUsager)
            {
                FenetreActive=new AnimalViewModel();
            }

        }

        public bool PeutClicker()
        {
            bool click = true;
            if(LeUsager.Pseudo=="")
            {
                click = false;
            }
            return click;
        }
        public BaseViewModel FenetreActive
        {
            get { return fenetreActive; }
            set
            {
                fenetreActive = value;
                OnPropertyChanged("FenetreActive");
            }
        }
           public MenuViewModel LeMenu
        {
            get { return menu; }
            set
            {
                menu = value;
                OnPropertyChanged("LeMenu");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
