﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using lab_2_XAML.ViewModel;

namespace lab_2_XAML.Commande
{
    class Quitter : ICommand
    {
        private MenuViewModel leMenu;

        public Quitter(MenuViewModel leMenu)
        {
            this.leMenu = leMenu;
        }
        public MenuViewModel LeMenu
        {
            get { return leMenu; }
            set
            {
                leMenu = value;

            }
        }
        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return leMenu.PeutQuitter();
        }

        public void Execute(object parameter)
        {
            leMenu.AQuitter();
        }
    }
}
