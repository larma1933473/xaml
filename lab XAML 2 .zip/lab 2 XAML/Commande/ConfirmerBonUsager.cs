﻿using System;
using System.Collections.Generic;
using System.Linq;
using lab_2_XAML.ViewModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace lab_2_XAML.Commande
{
    class ConfirmerBonUsager : ICommand
    {
        private MainViewModel connecter;

        public ConfirmerBonUsager(MainViewModel connecter)
        {
            this.connecter = connecter;
        }
        public MainViewModel Connecter
        {
            get { return connecter; }
            set
            {
                connecter = value;

            }
        }
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
        public bool CanExecute(object parameter)
        {
            return connecter.PeutClicker();
        }

        public void Execute(object parameter)
        {
            connecter.SeConnecter();
        }
    }
}
