﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Lab3XAML.Model;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3XAML.ViewModels
{

    class ProduitFinalViewModel : INotifyPropertyChanged
    {
        private Produit produit2;
        public ProduitFinalViewModel()
        {


        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
