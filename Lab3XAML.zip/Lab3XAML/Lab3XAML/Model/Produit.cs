﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3XAML.Model
{
    class Produit : INotifyPropertyChanged
    {
        private int largeur;
        private int  hauteur;
        private string nomProduit;
        private double prixProduit;
        private string couleur;

        public Produit(int largeur, int hauteur, string nomProduit, double prixProduit,string couleur)
        {
            Largeur = largeur;
            Hauteur = hauteur;
            NomProduit = nomProduit;
            PrixProduit = prixProduit;
            Couleur = couleur;
        }

        public int Largeur
        {
            get { return largeur; }
            set
            {
                largeur = value;
                OnPropertyChanged("Largeur");
            }
        }
        public int Hauteur
        {
            get { return hauteur; }
            set
            {
                hauteur = value;
                OnPropertyChanged("Hauteur");
            }
        }

        public string NomProduit
        {
            get { return nomProduit; }
            set
            {
                nomProduit = value;
                OnPropertyChanged("NomProduit");
            }
        }

        public double PrixProduit
        {
            get { return prixProduit; }
            set
            {
                prixProduit = value;
                OnPropertyChanged("PrixProduit");
            }
        }

        public string Couleur
        {
            get { return couleur; }
            set
            {
                couleur = value;
                OnPropertyChanged("Couleur");
            }
        }



        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
