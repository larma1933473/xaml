﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Lab3XAML.Model;
using Lab3XAML.Command;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3XAML.View_model
{
    class MainViewModel : INotifyPropertyChanged
    {
        private Produit produit;
       
        public MainViewModel()
        {
           
            produit = new Produit(0,0," ",0.00," ");
            
        }
        public bool PeutClicker()
        {
            
            return true;
        }
        public Produit LeProduit
        {
            get { return produit; }
            set
            {
                produit = value;
                OnPropertyChanged("LeProduit");
            }
        }
       
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
