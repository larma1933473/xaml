﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labJeuxMVVM.Model
{
    class Jeu : INotifyPropertyChanged
    {
        private int idJeu;
        private string nomJeu;
        private string emplacement;
        private int idJoueurJeu;

        public Jeu (int idJeu, string nomJeu, string emplacement, int idJoueurJeu)
        {
            IdJeu = idJeu;
            NomJeu = nomJeu;
            Emplacement = emplacement;
            IdJoueurJeu = idJoueurJeu;
           
        }

        public int IdJeu
        {
            get { return idJeu; }
            set
            {
                idJeu = value;
                OnPropertyChanged("IdJeu");
            }
        }
        public string NomJeu
        {
            get { return nomJeu; }
            set
            {
                nomJeu = value;
                OnPropertyChanged("NomJeu");
            }
        }

        public string Emplacement
        {
            get { return emplacement; }
            set
            {
                emplacement = value;
                OnPropertyChanged("Emplacement");
            }
        }

        public int IdJoueurJeu
        {
            get { return idJoueurJeu; }
            set
            {
                idJoueurJeu = value;
                OnPropertyChanged("IdJoueurJeu");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
