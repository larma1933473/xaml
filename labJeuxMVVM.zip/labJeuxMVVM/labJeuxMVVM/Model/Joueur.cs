﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labJeuxMVVM.Model
{
    class Joueur : INotifyPropertyChanged
    {
        private int idJoueur;
        private string nomJoueur;
        private string prenomJoueur;
        private string courrielJoueur;
        private string mdpJoueur;

        public Joueur(int idJoueur, string nomJoueur, string prenomJoueur, string courrielJoueur, string mdpJoueur)
        {
            IdJoueur = idJoueur;
            NomJoueur = nomJoueur;
            PrenomJoueur = prenomJoueur;
            CourrielJoueur = courrielJoueur;
            MdpJoueur = mdpJoueur;

        }

        public int IdJoueur
        {
            get { return idJoueur; }
            set
            {
                idJoueur = value;
                OnPropertyChanged("IdJoueur");
            }
        }
        public string NomJoueur
        {
            get { return nomJoueur; }
            set
            {
                nomJoueur = value;
                OnPropertyChanged("NomJoueur");
            }
        }

        public string PrenomJoueur
        {
            get { return prenomJoueur; }
            set
            {
                prenomJoueur = value;
                OnPropertyChanged("PrenomJoueur");
            }
        }

        public string CourrielJoueur
        {
            get { return courrielJoueur; }
            set
            {
                courrielJoueur = value;
                OnPropertyChanged("CourrielJoueur");
            }
        }
        public string MdpJoueur
        {
            get { return mdpJoueur; }
            set
            {
                mdpJoueur = value;
                OnPropertyChanged("MdpJoueur");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }


}
