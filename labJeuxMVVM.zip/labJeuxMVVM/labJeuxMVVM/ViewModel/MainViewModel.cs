﻿using System;
using System.Collections.Generic;
using labJeuxMVVM.Model;
using labJeuxMVVM.View;
using labJeuxMVVM.command;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data;
using System.Windows;

namespace labJeuxMVVM.ViewModel
{
    class MainViewModel : BaseViewModel,INotifyPropertyChanged
    {
        private Joueur joueur;
        private BaseCommand clickBoutonConnecter;


        public MainViewModel()
        {

            joueur = new Joueur(0, " ", " ", " ", " ");
            clickBoutonConnecter = new BaseCommand(EntrerInterfaceJeu, obj => true);
            ClickBoutonInscrire = new BaseCommand(Inscription, obj => true);
        }
        public BaseCommand ClickBoutonConnecter 
        {
            get { return clickBoutonConnecter; }
            set
            {
                clickBoutonConnecter = value;
                
            }
        }
        public ICommand ClickBoutonInscrire { get; set; }
        public void EntrerInterfaceJeu(object p)
        {
            
            try
            {
                SqlCommand courrielBD = new SqlCommand("SELECT * FROM tblJoueur WHERE courriel=@courriel AND motDePasse=@mdp", Con);            
                courrielBD.Parameters.Add("@courriel", System.Data.SqlDbType.VarChar, 50).Value = LeJoueur.CourrielJoueur;
                courrielBD.Parameters.Add("@mdp", System.Data.SqlDbType.VarChar, 50).Value = LeJoueur.MdpJoueur;
                SqlDataAdapter adapter = new SqlDataAdapter(courrielBD);
                DataSet dataset = new DataSet();
                adapter.Fill(dataset, "tblJoueur");
                courrielBD.ExecuteNonQuery();

                foreach (DataRow row in dataset.Tables[0].Rows)
                {
                    LeJoueur.CourrielJoueur = row[0].ToString();

                    DemarrageView win69 = new DemarrageView();
                    win69.DataContext = this;
                    win69.Show();
                }
               
            }
            catch (Exception e)
            {
                MessageBox.Show("erreur"+e);
            }


        }
        public void Inscription(object p)
        {
            try
            {
                SqlCommand inscription = new SqlCommand("INSERT INTO tblJoueur(nom,prenom,courriel,motDePasse) VALUES (@nom,@prenom,@courriel,@mdp)", Con);
                inscription.Parameters.Add("@nom", System.Data.SqlDbType.VarChar, 50).Value = LeJoueur.NomJoueur;
                inscription.Parameters.Add("@prenom", System.Data.SqlDbType.VarChar, 50).Value = LeJoueur.PrenomJoueur;
                inscription.Parameters.Add("@courriel", System.Data.SqlDbType.VarChar, 50).Value = LeJoueur.CourrielJoueur;
                inscription.Parameters.Add("@mdp", System.Data.SqlDbType.VarChar, 50).Value = LeJoueur.MdpJoueur;
                inscription.CommandType = CommandType.Text;
                inscription.ExecuteNonQuery();
            }
            catch(Exception e)
            {

            }
            

        }
        public Joueur LeJoueur
        {
            get { return joueur; }
            set
            {
                joueur = value;
                OnPropertyChanged("LeJoueur");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
