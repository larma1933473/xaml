﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labJeuxMVVM.ViewModel
{
    class BaseViewModel
    {
        private SqlConnection con;
        public BaseViewModel()
        {
            try
            {
                
                string connectionString = "Data Source = deptinfo420; Initial Catalog = JeuxBDMatis; Integrated Security = True";
                Con = new SqlConnection(connectionString);
                Con.Open();
            }
            catch (Exception e)
            {
            }


        }
        public SqlConnection Con
        {
            get { return con; }
            set
            {
                con = value;
                
            }
        }

    }
}
